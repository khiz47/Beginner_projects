
# File Renaming Program

This Python program renames all files in a specified folder by numbering them sequentially while retaining their original file extensions. It includes options for renaming files in reverse order, previewing the new file names before renaming, and recursively processing nested subdirectories.


## Features
1. Sequential Renaming: Files are renamed as 1.ext, 2.ext, 3.ext, etc., keeping their original extensions intact.   
2. Reverse Order Option: Allows users to rename files starting from the highest number.
3. Preview Mode: Displays the new file names before applying changes.
4. Recursive Renaming: Processes files in the specified folder and all its nested subdirectories.
5. Error Handling: Handles invalid folder paths, empty folders, permission issues, and other file system errors.
## How to Run the program

1. Clone or Download the program file to your local machine.
2. Open a terminal or command prompt and navigate to the directory containing the script.
3. Run the program using the following command:
- python <script_name>.py
- Replace <script_name>.py with the actual name of the Python file.


## Input and Output
Input

The program prompts the user to enter the path to the folder containing files to rename.

- Users are prompted to choose:
    - Whether to rename files in reverse order.
    - Whether to preview file names before renaming.
```
    - Please enter the path to the folder: /path/to/my_folder
    - Rename files in reverse order? (yes/no): no
    - Would you like to preview the new file names before renaming? (yes/no): yes

```
Output

The program displays a log of the renaming process, showing the original and new names of files.
    
If preview mode is enabled, the program displays a list of the new file names before applying changes.

```
Preview of renamed files:
image1.jpg -> 1.jpg
document.txt -> 2.txt
report.pdf -> 3.pdf
notes.docx -> 4.docx
music.mp3 -> 5.mp3
Do you want to proceed with renaming? (yes/no): yes

Renaming files...
File 'image1.jpg' renamed to '1.jpg'
File 'document.txt' renamed to '2.txt'
File 'report.pdf' renamed to '3.pdf'
File 'notes.docx' renamed to '4.docx'
File 'music.mp3' renamed to '5.mp3'
Renaming completed.

```
## Assumptions

- File Types: The program assumes that all items with file extensions are regular files (e.g., .jpg, .txt).
- Folder Path: The user provides a valid and accessible folder path.
- Sorting: Files are sorted alphabetically by default unless reverse order is specified.


## Author
Khizer Qureshi | Python Developer 