import os

def list_files_recursively(folder_path):
    """Lists all files in the folder and its subdirectories."""
    file_paths = []
    for root, _, files in os.walk(folder_path):
        for file in files:
            file_paths.append(os.path.join(root, file))
    return file_paths

def preview_file_names(files, reverse):
    """Previews the new file names based on sorting order."""
    sorted_files = sorted(files, key=lambda x: x.lower(), reverse=reverse)
    print("\nPreview of renamed files:")
    for index, file_path in enumerate(sorted_files, start=1):
        _, file_ext = os.path.splitext(file_path)
        print(f"{os.path.basename(file_path)} -> {index}{file_ext}")

def rename_files(files, reverse):
    #Renames the files based on sorting order.
    sorted_files = sorted(files, key=lambda x: x.lower(), reverse=reverse)
    print("\nRenaming files...")
    for index, file_path in enumerate(sorted_files, start=1):
        dir_name, file_name = os.path.split(file_path)
        _, file_ext = os.path.splitext(file_name)
        new_file_name = f"{index}{file_ext}"
        new_file_path = os.path.join(dir_name, new_file_name)
        
        try:
            os.rename(file_path, new_file_path)
            print(f"File '{file_name}' renamed to '{new_file_name}'")
        except PermissionError:
            print(f"Error: Unable to rename file '{file_name}' due to permission issues.")
        except Exception as e:
            print(f"Error: Unable to rename file '{file_name}'. Details: {e}")
    print("Renaming completed.")

def main():
    folder_path = input("Please enter the path to the folder: ").strip()
    if not os.path.exists(folder_path):
        print(f"Error: The folder '{folder_path}' does not exist.")
        return
    
    # Recursively list files in the folder
    files = list_files_recursively(folder_path)
    if not files:
        print("The folder is empty. No files to rename.")
        return

    # Ask the user for sorting preferences
    sort_order = input("Rename files in reverse order? (yes/no): ").strip().lower()
    reverse = sort_order == 'yes'

    # Preview file renaming
    preview_option = input("Would you like to preview the new file names before renaming? (yes/no): ").strip().lower()
    if preview_option == 'yes':
        preview_file_names(files, reverse)
        proceed = input("Do you want to proceed with renaming? (yes/no): ").strip().lower()
        if proceed != 'yes':
            print("Renaming canceled.")
            return

    # Rename files
    rename_files(files, reverse)

if __name__ == "__main__":
    main()
