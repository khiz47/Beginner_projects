import os
import zipfile
import pyzipper
from tqdm import tqdm

def zip_folder_with_password(folder_path, output_name=None, password=None):
    try:
        # Check if the provided path is valid
        if not os.path.exists(folder_path):
            print(f"Error: The folder '{folder_path}' does not exist.")
            return
        if not os.path.isdir(folder_path):
            print(f"Error: The path '{folder_path}' is not a valid directory.")
            return

        # Set the output .zip file name
        folder_name = os.path.basename(folder_path.rstrip(os.sep))
        if not output_name:
            output_name = folder_name
        zip_file_path = os.path.join(os.path.dirname(folder_path), f"{output_name}.zip")

        # Collect all files and directories for logging progress
        all_items = []
        for root, dirs, files in os.walk(folder_path):
            for f in files:
                full_path = os.path.join(root, f)
                all_items.append(full_path)

        if password:
            # Use pyzipper for password-protected zipping
            with pyzipper.AESZipFile(zip_file_path, 'w', compression=pyzipper.ZIP_DEFLATED, encryption=pyzipper.WZ_AES) as zipf:
                zipf.setpassword(password.encode())  # Apply the password
                for item in tqdm(all_items, desc="Zipping files", unit="item"):
                    try:
                        arcname = os.path.relpath(item, folder_path)  # Relative path inside ZIP
                        zipf.write(item, arcname)
                    except Exception as e:
                        print(f"Skipping file '{item}' due to error: {e}")
        else:
            # Use zipfile for non-password-protected zipping
            with zipfile.ZipFile(zip_file_path, 'w', compression=zipfile.ZIP_DEFLATED) as zipf:
                for item in tqdm(all_items, desc="Zipping files", unit="item"):
                    try:
                        arcname = os.path.relpath(item, folder_path)  # Relative path inside ZIP
                        zipf.write(item, arcname)
                    except Exception as e:
                        print(f"Skipping file '{item}' due to error: {e}")

        print(f"Success: Folder '{folder_name}' has been zipped as '{zip_file_path}'.")
        if password:
            print(f"The ZIP file is password-protected with the password: {password}")

    except PermissionError:
        print("Error: Permission denied. Please check your folder permissions.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

def main():
    # Get the folder path from the user
    folder_path = input("Enter the full path to the folder you want to zip: ").strip()
    if not folder_path:
        print("Error: No folder path provided.")
        return

    # Ask for a custom zip file name
    output_name = input("Enter the custom name for the zip file (or press Enter to use the folder name): ").strip()
    output_name = output_name if output_name else None

    # Ask for a password (optional)
    password = input("Enter a password to protect the zip file (or press Enter to skip): ").strip()
    password = password if password else None

    # Call the function to zip the folder
    zip_folder_with_password(folder_path, output_name, password)

if __name__ == "__main__":
    main()
