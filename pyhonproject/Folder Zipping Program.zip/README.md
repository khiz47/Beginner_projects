
# Folder Zipping Program

This Python program compresses a specified folder and its contents (including all subdirectories and files) into a .zip archive. The program offers options to specify a custom name for the .zip file, password-protect the archive, and display progress during the zipping process.



## Features

1. Custom ZIP File Name: Allows users to specify a custom name for the output .zip file.
2. Password Protection: Optionally encrypts the .zip file with a password using AES encryption.
3. Progress Indicator: Displays a progress bar while compressing files, useful for large directories.
4. Recursive Zipping: Preserves the folder structure, including all subdirectories and their files.
5. Error Handling: Handles invalid folder paths, permission errors, and empty directories gracefully.
## How to Run the Program

1. Clone or download the program file to your local machine.
2. Install required dependencies using the following command:
- pip install pyzipper tqdm
3. Open a terminal or command prompt and navigate to the directory containing the script.
4. Run the program using the following command:
- python <script_name>.py
Replace <script_name>.py with the actual name of the Python file.

## Input and Output
### Input

The program prompts the user to:

    1. Enter the full path of the folder to be zipped.
    2. Specify a custom name for the .zip file (optional).
    3. Provide a password to protect the .zip file (optional).
```
Enter the full path to the folder you want to zip: C:\Users\example\Documents\MyFolder
Enter the custom name for the zip file (or press Enter to use the folder name): MyCustomZip
Enter a password to protect the zip file (or press Enter to skip): MySecurePassword
```
### Output

The program generates a .zip file in the same directory as the input folder. If a password is provided, the .zip file is encrypted. A progress bar displays the zipping progress.

Example Output:
```
Zipping files: 100%|████████████████████████████████████████████████████| 25/25 [00:02<00:00, 12.34item/s]
Success: Folder 'MyFolder' has been zipped as 'C:\Users\example\Documents\MyCustomZip.zip'.
The ZIP file is password-protected with the password: MySecurePassword
```

## Assumptions

- Folder Path: The user provides a valid and accessible folder path.
- Empty Folders: If the input folder is empty, the program creates an empty .zip file.
- Compatibility: The resulting .zip file uses AES encryption and may require modern tools (e.g., 7-Zip, WinRAR) for extraction.
## Limitations

1. Password protection is only supported with pyzipper and may not work with some older extraction tools.
2. The program does not allow partial or selective zipping of specific files.
## Author

### Khizer Qureshi | Python Developer
Passionate about creating efficient and user-friendly automation scripts.