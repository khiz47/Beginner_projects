
# 2x2 Collage Creator Program

This Python program allows users to create a 2x2 collage from four input images. The program resizes the images, arranges them into a grid, and saves the final collage as a new image file. Users can specify the output file name and format.

## Features

1. Dynamic Resizing:
All input images are resized to the dimensions of the smallest image to ensure consistency in the collage.

2. Custom Output:
Users can specify a custom name and format (e.g., JPEG, PNG) for the output collage file.

3. 2x2 Grid Layout:
The program arranges the four images in the following layout:
| Image 1 | Image 2 |
| Image 3 | Image 4 |

4. Error Handling:

    - Validates input paths to ensure they point to image files.
    - Handles file not found, unsupported formats, and other unexpected errors gracefully.

5. Supported Formats:
The program supports popular image formats, including JPEG, PNG, and BMP.
## How to Run the Program

###  Prerequisites

- Install Python (version 3.7 or later).
- Install the Pillow library for image handling:
    
    pip install pillow

### Steps

1. Clone or download the script to your local machine.
2. Open a terminal or command prompt and navigate to the script's directory.
3. Run the program using the command:

    python mainthree.py

## Input and Output

### Input:

    1. Paths for Images: Users will provide file paths for four images to include in the collage.
    2. Output File Name: The desired name for the final collage file (excluding the file extension).
    3. Output File Format: The format for the collage file, such as jpg, png, etc.

```
Please enter the path for Image 1: C:\Users\Khizer\Pictures\image1.jpg
Please enter the path for Image 2: C:\Users\Khizer\Pictures\image2.jpg
Please enter the path for Image 3: C:\Users\Khizer\Pictures\image3.jpg
Please enter the path for Image 4: C:\Users\Khizer\Pictures\image4.jpg
Please specify the output file name (without extension): my_collage
Please specify the output file format (e.g., jpg, png): jpg

```
### Output:
The program generates a new image file with the specified name and format in the script's directory.

Example Output:
    Collage saved successfully as 'my_collage.jpg'

## Assumptions

1. All provided files are valid images in supported formats (e.g., JPEG, PNG, BMP).
2. The user has write permissions in the script's directory.
3. The script handles input errors but assumes valid file paths on successful input.

## Author

#### Khizer Qureshi
Python Developer with expertise in image processing and automation tools.