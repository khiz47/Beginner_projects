from PIL import Image
import os

def create_collage(image_paths, output_file, output_format):
    """
    Creates a 2x2 collage from four images.
    
    Args:
        image_paths (list): List of file paths for the four images.
        output_file (str): Name of the output collage file.
        output_format (str): Desired format for the output file (e.g., jpg, png).
    """
    # Validate that exactly 4 image paths are provided
    if len(image_paths) != 4:
        print("Error: Please provide exactly four image paths.")
        return
    
    try:
        # Load images
        images = [Image.open(path) for path in image_paths]
        
        # Resize all images to the size of the smallest image
        min_width = min(image.width for image in images)
        min_height = min(image.height for image in images)
        resized_images = [img.resize((min_width, min_height)) for img in images]
        
        # Create a new blank image for the collage
        collage_width = min_width * 2
        collage_height = min_height * 2
        collage = Image.new('RGB', (collage_width, collage_height))
        
        # Paste images into the collage
        collage.paste(resized_images[0], (0, 0))  # Top-left
        collage.paste(resized_images[1], (min_width, 0))  # Top-right
        collage.paste(resized_images[2], (0, min_height))  # Bottom-left
        collage.paste(resized_images[3], (min_width, min_height))  # Bottom-right
        
        # Save the collage
        output_path = f"{output_file}.{output_format.lower()}"
        collage.save(output_path, format=output_format.upper())
        print(f"Collage saved successfully as '{output_path}'")
    
    except FileNotFoundError:
        print("Error: One or more image paths are invalid.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

# Main program
if __name__ == "__main__":
    # Get user input for image paths
    image_paths = []
    for i in range(1, 5):
        path = input(f"Please enter the path for Image {i}: ").strip()
        image_paths.append(path)
    
    # Get output file name and format
    output_file = input("Please specify the output file name (without extension): ").strip()
    output_format = input("Please specify the output file format (e.g., jpg, png): ").strip()
    
    # Create collage
    create_collage(image_paths, output_file, output_format)
